import { PortableText } from "@portabletext/react";
import type { PortableTextBlock } from "@portabletext/types";
import { renderBlock } from "@/utils/renderBlock";
import { renderMarks } from "@/utils/renderMarks";

type EmbedMap = Record<string, {
  type: "oembed" | "ogp";
  html?: string;
  title?: string;
  description?: string;
  image?: string;
  url?: string;
} | null>;

interface Props {
  value: PortableTextBlock[];
  embedMap?: EmbedMap;
  headingLink?: boolean;
}

export default function PortableTextRendererSSR({
  value,
  embedMap = {},
  headingLink = true,
}: Props) {
  if (!Array.isArray(value)) {
    console.warn("[PortableTextRendererSSR] Invalid value:", value);
    return null;
  }

  return (
    <PortableText
      value={value}
      components={{
        block: (props) => renderBlock({ ...props, embedMap, headingLink }),
        marks: renderMarks,
      }}
    />
  );
}
