import type { EmbedData } from "@/components/SmartLink";

export async function fetchEmbedData(url: string): Promise<EmbedData | null> {
  try {
    const res = await fetch(`/api/fetch-embed?url=${encodeURIComponent(url)}`);
    const json = await res.json();

    if (
      typeof json === "object" &&
      (json.type === "oembed" || json.type === "ogp")
    ) {
      return json as EmbedData;
    }

    return null;
  } catch (err) {
    console.warn("[fetchEmbedData] failed:", url, err);
    return null;
  }
}