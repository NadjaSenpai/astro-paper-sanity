export function extractBareLinksFromPortableText(blocks: any[]): string[] {
  const links: string[] = [];

  for (const block of blocks) {
    if (
      block._type === "block" &&
      block.children?.length === 1 &&
      block.children[0]?._type === "span"
    ) {
      const text = block.children[0].text?.trim();
      if (text?.match(/^https?:\/\/[^\s]+$/)) {
        links.push(text);
      }
    }
  }

  return links;
}