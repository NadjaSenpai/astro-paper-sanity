export function isActive(path: string, current: string) {
  return current === path;
}
